# M3-07 私下交接证据包

本包来自 2026-11-04 的真实 GPU 运行 dbdffce3-e453-46bf-b962-d66a424d7199。原始训练代码为 fe5c87e，真实成功清单均记录 working_tree_dirty=false。B 尚未完成复核。

## 内容

- report.json：原始报告逐字节复制，9 项场景、9 个任务（4 个 COMPLETED、5 个预期 FAILED）。
- browser-*：原始及 CJK 复查的 result/submitted、20 张截图、10 份 trace。优先查看 *-cjk 的截图；最初 browser-success 的 result/trace 包含真正上传、两次提交与 GPU 轮询，原始截图缺中文字体。
- data/llmcloud.db：使用 SQLite backup 从只读源库取得的一致性快照，包含真实任务/数据集元数据，没有用户记录。
- metadata/outputs：原清单、指标、配置和失败诊断的逐字节副本。
- handoff.json：来源、范围、文件数和源文件哈希；SHA256SUMS：包内文件校验值。

本包不含数据集正文、模型缓存、Adapter/tokenizer 权重、checkpoint 或原始服务日志。只凭本包不能重新审计全部权重/重新训练。trace 是真实浏览器记录，含本次公开工程格式样例的请求内容；请在团队内传递。

## 先离线复核

1. 保留收到的 ZIP 和外部 .sha256；在解压目录运行 sha256sum -c SHA256SUMS（Windows 可用 WSL）。
2. 核对报告的任务 ID/UTC 区间/错误码/恢复结果，查看 browser-*-cjk/desktop.png 和 mobile.png。report.browser_url 是已经停止的历史地址，不是当前可访问服务。
3. trace 用已有 frontend 依赖查看：在仓库 frontend 中运行 npx --no-install playwright show-trace <绝对路径>/browser-success/trace.zip。该步骤只看原始记录，不执行 GPU 训练。
4. SQLite 可只读查看，例如 sqlite3 'file:<绝对路径>/data/llmcloud.db?mode=ro'。没有 sqlite3 CLI 时可用 Python sqlite3，不必另装数据库服务。
5. 写独立 YYYY-MM-DD-m3-07-b.md：区分代码/CPU 检查、真实证据复核、人工页面操作、仍未验证的内容；不要把收到证据包当作已经完成复核。

## 可选：本机重开已存任务页面

先完整复制本解压目录为工作副本，保留原包及其校验文件。已同步项目 Python 基础依赖、frontend npm ci 及 Playwright Chromium/系统库/中文字体后，在仓库根目录运行：

uv run --locked --no-sync python scripts/check_m3_acceptance.py --review-run <工作副本绝对路径>

此命令仅启动实际 API/Vite 和浏览器查询快照中的既有任务，自动结束；无需 Redis/模型缓存/GPU。它会更新工作副本的报告/截图，故不能在原始证据目录上运行后再声称校验值未变。它不提供持续可访问的验收服务，不验证新的排队/训练，也不替代双方的人工联调。若需要从新上传到真实 GPU 完成的人工操作，另约 A 的服务/GPU 时段。
